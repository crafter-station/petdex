# Denissexy ITier

A cheerful aqua-and-cream pixel robot pet with a green face screen, rosy cheeks, and a red antenna light.

## Install locally

```bash
mkdir -p ~/.codex/pets/denissexy-itier
unzip denissexy-itier.zip -d ~/.codex/pets/denissexy-itier
```

Generated for Petdex.
